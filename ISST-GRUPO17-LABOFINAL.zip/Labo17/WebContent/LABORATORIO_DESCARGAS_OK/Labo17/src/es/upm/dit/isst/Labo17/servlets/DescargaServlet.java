package es.upm.dit.isst.Labo17.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.Labo17.dao.ComunidadDAO;
import es.upm.dit.isst.Labo17.dao.ComunidadDAOImplementation;
import es.upm.dit.isst.Labo17.model.Comunidad;



@WebServlet("/DescargaServlet")
public class DescargaServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
		String comunidad = req.getParameter("comunidad");
		
		ComunidadDAO tdao = ComunidadDAOImplementation.getInstance();
//		Comunidad comunidadVotos = new Comunidad();
		Comunidad comunidadVotos = tdao.read(comunidad);
		
		resp.setContentLength(comunidadVotos.getDocument().length);
		resp.getOutputStream().write(comunidadVotos.getDocument());
	}


}

package es.upm.dit.isst.Labo17.auxiliar;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAO;
import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAOImplementation;
import es.upm.dit.isst.Labo17.dao.ResultadoDAO;
import es.upm.dit.isst.Labo17.dao.ResultadoDAOImplementation;
import es.upm.dit.isst.Labo17.model.PartidoPolitico;
import es.upm.dit.isst.Labo17.model.Resultado;

public class LeerFile {
	


	    public Collection<Resultado> calcula(File f) {
	    	
	    	Collection<Resultado> resultados = new ArrayList<Resultado>();
	        BufferedReader br = null;
	        String line = "";
	        String cvsSplitBy = ";";
	        ResultadoDAO t1 = ResultadoDAOImplementation.getInstance();
	        PartidoPoliticoDAO pdao = PartidoPoliticoDAOImplementation.getInstance();
	        try {
	            br = new BufferedReader(new FileReader(f));

	        	int lNumeroLineas = 0;

	            while ((line = br.readLine()) != null) {
	            	lNumeroLineas++;
	                // use comma as separator
	                String[] votosExcel = line.split(cvsSplitBy);
	                System.out.println(votosExcel[0]);
	                System.out.println(votosExcel[1]);
	                System.out.println(votosExcel[2]);
	                
	                Resultado resultado = new Resultado();
	                PartidoPolitico partido = new PartidoPolitico();
	                partido.setAcronimo(votosExcel[0]);
	                partido.setNombre(votosExcel[1]);
	                
	                resultado.setPartido(partido);
	                resultado.setVotosObtenidos(Integer.parseInt(votosExcel[2]));
	                resultado.setId(lNumeroLineas);
	                System.out.println(lNumeroLineas);
	                
	                t1.update(resultado);
	                pdao.update(partido);
	                
	                resultados.add(resultado);
	            }

	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (br != null) {
	                try {
	                    br.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	        
	        
			return resultados;

	    }

	
	
	

}

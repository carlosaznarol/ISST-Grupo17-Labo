package es.upm.dit.isst.Labo17.test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.Labo17.dao.ResultadoDAO;
import es.upm.dit.isst.Labo17.dao.ResultadoDAOImplementation;
import es.upm.dit.isst.Labo17.model.PartidoPolitico;
import es.upm.dit.isst.Labo17.model.Resultado;

class TestResultadoDAOImplementation {
	
	private final Resultado res = new Resultado();
	ResultadoDAO resdao = ResultadoDAOImplementation.getInstance();
	
	private final int escanos = 30;
	//private final PartidoPolitico partido = new PartidoPolitico();
	private final int votosObtenidos = 7500000;	
	PartidoPolitico PP = res.getPartido();
	@BeforeEach
	void setUp() throws Exception {
		
		res.setId(1);
		res.setEscanos(escanos);
		res.setPartido(PP);
		res.setVotosObtenidos(votosObtenidos);
		resdao.create(res);
		System.out.println(res);
	}

	@AfterEach
	void tearDown() throws Exception {
		resdao.delete(resdao.read(1));
	}

	@Test
	void testCreate() {
		assertNotNull(resdao.read(1));
	}

	@Test
	void testRead() {
		//assertEquals("PP",resdao.read(1).getPartido());
		assertEquals(30,resdao.read(1).getEscanos());
		assertEquals(7500000,resdao.read(1).getVotosObtenidos());
	}

	@Test
	void testUpdate() {
		
		res.setEscanos(40);
		res.setPartido(PP);
		res.setVotosObtenidos(votosObtenidos);
		resdao.update(res);
		assertNotEquals(30,resdao.read(1).getEscanos());
	}

	@Test
	void testDelete() {
		
		resdao.delete(res);
		assertNotNull(resdao.read(res.getId()));
		
	}

	@Test
	void testReadAll() {
		assertFalse(resdao.readAll().isEmpty());
	}

}
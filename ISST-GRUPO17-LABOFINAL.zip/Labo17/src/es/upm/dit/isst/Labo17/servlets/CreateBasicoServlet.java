package es.upm.dit.isst.Labo17.servlets;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;

import es.upm.dit.isst.Labo17.auxiliar.Dont;
import es.upm.dit.isst.Labo17.auxiliar.SaintLague;
import es.upm.dit.isst.Labo17.dao.ComunidadDAO;
import es.upm.dit.isst.Labo17.dao.ComunidadDAOImplementation;
import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAO;
import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAOImplementation;
import es.upm.dit.isst.Labo17.dao.ResultadoDAO;
import es.upm.dit.isst.Labo17.dao.ResultadoDAOImplementation;
import es.upm.dit.isst.Labo17.model.Comunidad;
import es.upm.dit.isst.Labo17.model.PartidoPolitico;
import es.upm.dit.isst.Labo17.model.Resultado;




@SuppressWarnings("serial")
@WebServlet("/CreateBasicoServlet")

public class CreateBasicoServlet extends HttpServlet {



	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


		
		//-----OBTENEMOS LOS VOTOS INTRODUCIDOS POR EL USUARIO
		String tipoLey = req.getParameter( "tipoLey" );
		int leyElegida = Integer.parseInt(tipoLey);
		String comunidad = req.getParameter("comunidad");
		
		//--------SACAMOS EL NUMERO DE ESCANOS DE LA COMUNIDAD SELECCIONADA
		ComunidadDAO tdao = ComunidadDAOImplementation.getInstance();
		Comunidad comunidadBBDD = new Comunidad();
		comunidadBBDD = tdao.read(comunidad);

	
		Collection<Resultado> resultados = new ArrayList<Resultado>();
		
			

		//String tipoElecciones = req.getParameter( "tipoElecciones" );
		String votosPSOE = req.getParameter( "votosPSOE" );
		String votosPP = req.getParameter( "votosPP" );
		String votosCiudadanos = req.getParameter( "votosCiudadanos" );
		String votosVox = req.getParameter( "votosVox" );
		String votosPodemos = req.getParameter( "votosPodemos" );
		String votosOtros = req.getParameter( "votosOtros" );
		

		
		
		//------CONVERTIMOS LOS VOTOS EN ENTEROS
		//int escanosARepartirOk= Integer.parseInt(escanosARepartir);
		int escanos = comunidadBBDD.getEscanos();
		int votosPPOk = Integer.parseInt(votosPP);
		int votosPSOEOk = Integer.parseInt(votosPSOE);
		int votosCiudadanosOk = Integer.parseInt(votosCiudadanos);
		int votosVoxOk = Integer.parseInt(votosVox);
		int votosPodemosOk = Integer.parseInt(votosPodemos);
		int votosOtrosOk = Integer.parseInt(votosOtros);

		
		ResultadoDAO t1 = ResultadoDAOImplementation.getInstance();
        PartidoPoliticoDAO pdao = PartidoPoliticoDAOImplementation.getInstance();
		
		
				
      
		//-----------PP-------------
        
        Resultado resultPP = new Resultado();
        PartidoPolitico partPolPP = new PartidoPolitico();
        
		partPolPP.setNombre("Partido Popular");
		partPolPP.setAcronimo("PP");

		resultPP.setPartido(partPolPP);
		resultPP.setVotosObtenidos(votosPPOk);
		resultPP.setId(1);
		
		t1.update(resultPP);
		pdao.update(partPolPP);
		
		resultados.add(resultPP);


		//-----------PSOE-------------
		
		Resultado resultPSOE = new Resultado();
		PartidoPolitico partPolPSOE = new PartidoPolitico();
		
		partPolPSOE.setNombre("Partido Socialista Obrero Espanol");
		partPolPSOE.setAcronimo("PSOE");

		
		resultPSOE.setVotosObtenidos(votosPSOEOk);
		resultPSOE.setPartido(partPolPSOE);
		resultPSOE.setId(2);

		
		pdao.update(partPolPSOE);
		t1.update(resultPSOE);
		resultados.add(resultPSOE);


		//----------VOX-------------
		Resultado resultVox = new Resultado();
		PartidoPolitico partPolVox = new PartidoPolitico();
		
		partPolVox.setNombre("Vox");
		partPolVox.setAcronimo("Vox");

		resultVox.setVotosObtenidos(votosVoxOk);
		resultVox.setPartido(partPolVox);
		resultVox.setId(3);

		
		pdao.update(partPolVox);
		t1.update(resultVox);
		resultados.add(resultVox);

		//---------CIUDADANOS----------
		Resultado resultCiudadanos = new Resultado();
		PartidoPolitico partPolCiudadanos = new PartidoPolitico();
		
		partPolCiudadanos.setNombre("Ciudadanos");
		partPolCiudadanos.setAcronimo("CS");

		
		resultCiudadanos.setVotosObtenidos(votosCiudadanosOk);
		resultCiudadanos.setPartido(partPolCiudadanos);
		resultCiudadanos.setId(4);

		
		pdao.update(partPolCiudadanos);
		t1.update(resultCiudadanos);
		resultados.add(resultCiudadanos);


		//-----------PODEMOS----------
		Resultado resultPodemos = new Resultado();
		PartidoPolitico partPolPodemos = new PartidoPolitico();
		
		partPolPodemos.setNombre("Podemos");
		partPolPodemos.setAcronimo("Podemos");

		resultPodemos.setVotosObtenidos(votosPodemosOk);
		resultPodemos.setPartido(partPolPodemos);
		resultPodemos.setId(5);

		
		pdao.update(partPolPodemos);
		t1.update(resultPodemos);
		resultados.add(resultPodemos);


		//---------OTROS-------
		Resultado resultOtros = new Resultado();
		PartidoPolitico partPolOtros = new PartidoPolitico();
		partPolOtros.setNombre("Otros");
		partPolOtros.setAcronimo("Otros");

		
		resultOtros.setId(6);
		
		resultOtros.setVotosObtenidos(votosOtrosOk);
		resultOtros.setPartido(partPolOtros);

		
		pdao.update(partPolOtros);
		
		t1.update(resultOtros);
		resultados.add(resultOtros);
		
		

		
		
		
		
		Collection<Resultado> resultados2 = new ArrayList<Resultado>();
		
		if(leyElegida==0) {
			SaintLague saint = new SaintLague();
			resultados2 = saint.saintLague(resultados, escanos);
			
		}else if(leyElegida==1) {
			Dont dont = new Dont();
			resultados2 = dont.leyDont(resultados, escanos);
			
		}
		
		
		for(Resultado r : resultados2) {
			
			t1.update(r);
		}


		
		
		resp.sendRedirect( req.getContextPath() + "/SimulacionServlet");


	}	

}

package es.upm.dit.isst.Labo17.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.Labo17.dao.ComunidadDAO;
import es.upm.dit.isst.Labo17.dao.ComunidadDAOImplementation;

import es.upm.dit.isst.Labo17.model.Comunidad;
;

class TestComunidadDAOImplementation {

	private final Comunidad com = new Comunidad();
	ComunidadDAO comdao = ComunidadDAOImplementation.getInstance();
	
	private final int escanos = 30;
	private final String nombreCom = "Castilla y Leon";
	private final int censo = 2300000;	
	
	@BeforeEach
	void setUp() throws Exception {
		com.setNombre(nombreCom);
		
		com.setEscanos(escanos);
		com.setCenso(censo);
		comdao.create(com);
		System.out.println(com);
	}

	@AfterEach
	void tearDown() throws Exception {
		comdao.delete(comdao.read(nombreCom));
	}

	@Test
	void testCreate() {
		assertNotNull(comdao.read(nombreCom));
	}

	@Test
	void testRead() {
		assertEquals(30,comdao.read(nombreCom).getEscanos());
		assertEquals(2300000,comdao.read(nombreCom).getCenso());
	}

	@Test
	void testUpdate() {
		int com1 =com.getEscanos();
		com.setEscanos(40);
		comdao.update(com);
		assertNotEquals(com1,comdao.read(nombreCom).getEscanos());
	}

	@Test
	void testDelete() {
		
		int size1 = comdao.readAll().size();
		comdao.delete(comdao.read(nombreCom));
		assertFalse(comdao.readAll().size()<size1);
		
	}

	@Test
	void testReadAll() {
		assertFalse(comdao.readAll().isEmpty());
	}

}

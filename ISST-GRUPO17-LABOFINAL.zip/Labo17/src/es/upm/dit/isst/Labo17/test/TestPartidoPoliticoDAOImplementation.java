package es.upm.dit.isst.Labo17.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAO;
import es.upm.dit.isst.Labo17.dao.PartidoPoliticoDAOImplementation;
import es.upm.dit.isst.Labo17.model.PartidoPolitico;

class TestPartidoPoliticoDAOImplementation {
	
	PartidoPolitico part = new PartidoPolitico();
	PartidoPoliticoDAO partdao = PartidoPoliticoDAOImplementation.getInstance();
	
	private String acronimo = "PP";
	private final String nombrePart = "Partido Popular";
	@BeforeEach
	void setUp() throws Exception {
		part.setAcronimo(acronimo);
		
		part.setNombre(nombrePart);
		partdao.create(part);
		System.out.println(part);
	}

	@AfterEach
	void tearDown() throws Exception {
		partdao.delete(partdao.read(acronimo));
	}

	@Test
	void testCreate() {
		assertNotNull(partdao.read(acronimo));
	}

	@Test
	void testRead() {
		
		assertEquals("Partido Popular",partdao.read(acronimo).getNombre());
	}

	@Test
	void testUpdate() {
		String part1 =part.getNombre();
		part.setNombre("Podemos");
		partdao.update(part);
		assertNotEquals(part1,partdao.read(acronimo).getNombre());
	}

	@Test
	void testDelete() {
		int size1 = partdao.readAll().size();
		partdao.delete(partdao.read(acronimo));
		assertFalse((partdao.readAll().size()<size1));
	}

	@Test
	void testReadAll() {
		assertFalse(partdao.readAll().isEmpty());
	}

}

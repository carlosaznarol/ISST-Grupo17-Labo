package es.upm.dit.isst.Labo17.servlets;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;

import es.upm.dit.isst.Labo17.auxiliar.Dont;
import es.upm.dit.isst.Labo17.auxiliar.SaintLague;
import es.upm.dit.isst.Labo17.auxiliar.LeerFile;
import es.upm.dit.isst.Labo17.dao.ComunidadDAO;
import es.upm.dit.isst.Labo17.dao.ComunidadDAOImplementation;
import es.upm.dit.isst.Labo17.dao.EleccionDAO;
import es.upm.dit.isst.Labo17.dao.EleccionDAOImplementation;
import es.upm.dit.isst.Labo17.dao.ResultadoDAO;
import es.upm.dit.isst.Labo17.dao.ResultadoDAOImplementation;
import es.upm.dit.isst.Labo17.model.Comunidad;
import es.upm.dit.isst.Labo17.model.Eleccion;
import es.upm.dit.isst.Labo17.model.Resultado;





@MultipartConfig
@WebServlet("/SubirServlet")
public class SubirServlet extends HttpServlet  {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	//	Part filePart = req.getPart("file");
		Part filePart = req.getPart("file");
		
		String ley = req.getParameter( "ley" );
		
		int leyElegida = Integer.parseInt(ley);
		
		
		//InputStream fileContent = filePart.getInputStream();
		InputStream fileContent = filePart.getInputStream();
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		byte[] buffer = new byte[10240];
		for (int length = 0; (length = fileContent.read(buffer)) > 0;) output.write(buffer, 0, length);
		
		File f = new File("Ejemplo.csv");
		FileOutputStream fOS = new FileOutputStream(f);
		try {
			if(!f.exists()) {
				f.createNewFile();
			}
			fOS.write(output.toByteArray());
		} finally {
			fOS.close();
		}
		
		String comunidad = req.getParameter("comunidad");
		
		ComunidadDAO tdao = ComunidadDAOImplementation.getInstance();
		Comunidad comunidadVotos = new Comunidad();
		comunidadVotos = tdao.read(comunidad);
		
		tdao.update(comunidadVotos);
		
		LeerFile c = new LeerFile();
		
		
		Collection<Resultado> resultados1 = c.calcula(f);
		int escanos = comunidadVotos.getEscanos();
		
		Collection<Resultado> resultados = new ArrayList<Resultado>();
		
		if(leyElegida==0) {
			SaintLague saint = new SaintLague();
			resultados = saint.saintLague(resultados1, escanos);
			
		}
		if(leyElegida==1) {
			Dont dont = new Dont();
			resultados = dont.leyDont(resultados1, escanos);
			
		}
		
		
		
		Eleccion eleccion = new Eleccion();
		eleccion.setComunidad(comunidadVotos);
		eleccion.setResultados(resultados);
		eleccion.setLey(1);
		eleccion.setTipo(1);
		eleccion.setId(2);
		
		EleccionDAOImplementation edao = EleccionDAOImplementation.getInstance();
		edao.update(eleccion);
		
	
		req.getSession().setAttribute( "Result_lista", resultados );
		req.getSession().setAttribute( "comunidad", comunidadVotos );
		resp.sendRedirect( req.getContextPath() + "/SimuAvanzado.jsp");			

	}
	
}

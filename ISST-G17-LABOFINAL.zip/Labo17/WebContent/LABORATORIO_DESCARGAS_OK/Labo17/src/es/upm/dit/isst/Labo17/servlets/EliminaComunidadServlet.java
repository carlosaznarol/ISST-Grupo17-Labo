package es.upm.dit.isst.Labo17.servlets;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import es.upm.dit.isst.Labo17.auxiliar.Dont;
import es.upm.dit.isst.Labo17.auxiliar.LeerFile;
import es.upm.dit.isst.Labo17.auxiliar.SaintLague;
import es.upm.dit.isst.Labo17.dao.ComunidadDAO;
import es.upm.dit.isst.Labo17.dao.ComunidadDAOImplementation;
import es.upm.dit.isst.Labo17.dao.EleccionDAOImplementation;
import es.upm.dit.isst.Labo17.model.Comunidad;
import es.upm.dit.isst.Labo17.model.Eleccion;
import es.upm.dit.isst.Labo17.model.Resultado;


@WebServlet("/EliminaComunidadServlet")
public class EliminaComunidadServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String comunidad = req.getParameter("comunidad");
		ComunidadDAO tdao = ComunidadDAOImplementation.getInstance();
		Comunidad comunity = tdao.read(comunidad);
		tdao.delete(comunity);
		req.getSession().setAttribute( "Comunidad_list", tdao.readAll() );
		getServletContext().getRequestDispatcher( "/ComunidadesAutonomas.jsp" ).forward( req, resp );		

	}
}

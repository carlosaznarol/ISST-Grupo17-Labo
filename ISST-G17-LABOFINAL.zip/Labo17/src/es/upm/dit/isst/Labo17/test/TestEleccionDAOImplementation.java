package es.upm.dit.isst.Labo17.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.upm.dit.isst.Labo17.dao.EleccionDAO;
import es.upm.dit.isst.Labo17.dao.EleccionDAOImplementation;
import es.upm.dit.isst.Labo17.model.Comunidad;
import es.upm.dit.isst.Labo17.model.Eleccion;

class TestEleccionDAOImplementation {

	Eleccion elec = new Eleccion();
	EleccionDAO elecdao = EleccionDAOImplementation.getInstance();
	
	private int ley = 1;
	private int tipo = 1;
	
	Comunidad Andalucia = elec.getComunidad();
	
	@BeforeEach
	void setUp() throws Exception {
		elec.setId(1);
		
		elec.setComunidad(Andalucia);
		elec.setLey(ley);
		elec.setTipo(tipo);
		
		elecdao.create(elec);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		elecdao.delete(elecdao.read(1));
	}

	@Test
	void testCreate() {
		assertNotNull(elecdao.read(1));
	}

	@Test
	void testRead() {
		assertEquals(1,elecdao.read(1).getLey());
		assertEquals(1,elecdao.read(1).getTipo());
	}

	@Test
	void testUpdate() {
		int ley1 = elec.getLey();
		elec.setId(1);
		elec.setComunidad(Andalucia);
		elec.setLey(2);
		elec.setTipo(tipo);
		elecdao.update(elec);
		assertNotEquals(ley1,elecdao.read(1).getLey());
		
	}

	@Test
	void testDelete() {

		elecdao.delete(elec);
		assertNotNull(elecdao.read(elec.getId()));
		
	}

	@Test
	void testReadAll() {
		assertFalse(elecdao.readAll().isEmpty());
	}

}
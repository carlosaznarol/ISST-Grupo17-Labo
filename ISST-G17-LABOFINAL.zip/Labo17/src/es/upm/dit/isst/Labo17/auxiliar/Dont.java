package es.upm.dit.isst.Labo17.auxiliar;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import es.upm.dit.isst.Labo17.model.Resultado;

public class Dont {
	
public Collection<Resultado> leyDont(Collection<Resultado> resultados, int escanos){
		
		Resultado resultado = new Resultado();
		Map<String,Integer> votosIniciales= new HashMap<String,Integer>();
		
		//Metemos en un mapa auxiliar los votos iniciales
		for (Resultado a : resultados) {
			votosIniciales.put(a.getPartido().getAcronimo(), a.getVotosObtenidos());
		}
		//Inicializamos la variable resultado con voto de 0 para que no pete al comprobarlo
		resultado.setVotosObtenidos(0);
		
		//Cogemos el resultado con más votos
			for(int i = 1; i <= escanos; i++) {
				for(Resultado a : resultados) {
					if(a.getVotosObtenidos() > resultado.getVotosObtenidos())
						resultado = a;	
				}
				System.out.println(resultado.getPartido().getAcronimo());
				
				//Asignamos un escaño a ese partido
				resultado.setEscanos(resultado.getEscanos() + 1);
				System.out.println(votosIniciales.get(resultado.getPartido().getAcronimo()));
				
				//Le restamos los votos para la siguiente iteracción
				resultado.setVotosObtenidos(votosIniciales.get(resultado.getPartido().getAcronimo())/(resultado.getEscanos() + 1));
				System.out.println(resultado.getVotosObtenidos());
				
				//Insertamos el resultado actualizado en la biblioteca de resultados
				for(Resultado a : resultados) {
					if((a.getPartido().getAcronimo()).equals(resultado.getPartido().getAcronimo())) {
						resultados.remove(a);
						resultados.add(resultado);
						break;
					}
				}
			}
			
			//Volvemos a asignar a cada resultado sus votos iniciales para su presentacion en la tabla del .jsp
			for (Resultado a : resultados) {
				a.setVotosObtenidos(votosIniciales.get(a.getPartido().getAcronimo()));
			}
			
			return resultados;
		}

}
